#
# Cookbook Name:: appbox
# Recipe:: package_update
#
# Update apt-get packages.
#

include_recipe "apt"

