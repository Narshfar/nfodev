#
# Cookbook Name:: web-server
# Recipe:: NFO_Database
#
# Copyright (c) 2015 The Authors, All Rights Reserved.
# 

include_recipe "database::postgresql"

postgresql_database